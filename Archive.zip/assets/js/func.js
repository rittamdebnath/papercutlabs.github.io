(function(){
  console.log("Hello Developer! We are hiring talents like you. If you're looking for a job! Mail you're resume at papercutlabs@gmail.com");
  
})();
